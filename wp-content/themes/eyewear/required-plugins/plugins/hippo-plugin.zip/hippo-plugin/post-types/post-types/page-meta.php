<?php

	defined( 'ABSPATH' ) or die( 'Keep Silent' );

	// $prefix = 'page_';

	// $fields = array(

	//     array(
	//         'label' => 'Header Image', // <label>
	//         'desc'  => 'Header background image. dimension: 1400px &times; 400px', // description
	//         'id'    => $prefix . 'header_image', // field id and name
	//         'type'  => 'image', // type of field
	//     ),

	// );

	/**
	 * Instantiate the class with all variables to create a meta box
	 * var $id string meta box id
	 * var $title string title
	 * var $fields array fields
	 * var $page string|array post type to add meta box to
	 * var $js bool including javascript or not
	 */
	//new Hippo_Custom_Add_Meta_Box('page_options', 'Page Options', $fields, 'page', TRUE);


